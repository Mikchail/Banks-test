import { Controller } from '@nestjs/common';

@Controller('payment-shedule')
export class PaymentSheduleController {}
