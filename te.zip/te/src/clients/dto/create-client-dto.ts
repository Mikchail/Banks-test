export class CreateClientDto {
  readonly email: string;
  readonly name: string;
  readonly phone: string;
  readonly passportNumber: number;
}