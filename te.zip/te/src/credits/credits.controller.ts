import { Controller } from '@nestjs/common';

@Controller('credits')
export class CreditsController {}
