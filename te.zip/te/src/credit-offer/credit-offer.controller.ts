import { Controller } from '@nestjs/common';

@Controller('credit-offer')
export class CreditOfferController {}
