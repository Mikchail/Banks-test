export class CreateBankDto {
  readonly title: string;
  readonly limit: string;
}