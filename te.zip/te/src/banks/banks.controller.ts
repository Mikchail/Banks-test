import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { BanksService } from './banks.service';
import { CreateBankDto } from './dto/create-bank-dto';

@Controller('banks')
export class BanksController {

  constructor(private banksService: BanksService) { }

  @Post()
  saveBank(@Body() dto: CreateBankDto) {
    return this.banksService.saveBank(dto);
  }

  @Get("/:id")
  getBank(@Param("id") id: string) {
    return this.banksService.getBank(id);
  }

  @Delete("/:id")
  deleteBank(@Param("id") id: string) {
    return this.banksService.deleteBank(id);
  }

  @Get()
  getAllBanks() {
    return this.banksService.getAllBanks();
  }
}
